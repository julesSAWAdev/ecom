 <div class="footer">
                <div class="float-right">
                    La Corniche Motel <strong></strong> 
                </div>
                <div>
                    <strong>Copyright</strong> Reserved &copy; 2020
                </div>
            </div>